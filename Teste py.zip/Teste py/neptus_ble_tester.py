"""
=============================================================
  NEPTUS - Testador de Comunicação BLE com ESP32
=============================================================
  Dependência: pip install bleak
  Uso:         python neptus_ble_tester.py
=============================================================
"""

import asyncio
import json
import sys
from datetime import datetime
from bleak import BleakClient, BleakScanner

# ─────────────────────────────────────────────
#  UUIDs do serviço NUS (Nordic UART Service)
#  Padrão usado pelo ESP32 para comunicação serial via BLE
# ─────────────────────────────────────────────
NUS_SERVICE_UUID  = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
NUS_RX_CHAR_UUID  = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"  # Escrita  → ESP32
NUS_TX_CHAR_UUID  = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"  # Leitura ← ESP32

# ─────────────────────────────────────────────
#  Configurações
# ─────────────────────────────────────────────
DEVICE_NAME_FILTER = "ESP32"   # Altere para o nome do seu ESP32
SCAN_TIMEOUT_SEC   = 10
LOG_FILE           = "neptus_ble_log.txt"


# ══════════════════════════════════════════════
#  Utilitários de Log
# ══════════════════════════════════════════════

def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    line = f"[{ts}] [{level}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def log_rx(raw: str):
    """Interpreta e exibe as mensagens recebidas do ESP32."""
    log(f"← ESP32: {raw!r}", "RX")

    # Tenta parsear como JSON (pacote de monitoração)
    if raw.strip().startswith("{"):
        try:
            data = json.loads(raw)
            log(f"   📊 turbidez={data.get('turbidez')} NTU | "
                f"nível='{data.get('nivel')}' | "
                f"ts={data.get('timestamp')}", "JSON")
        except json.JSONDecodeError:
            log("   ⚠ JSON malformado", "WARN")
        return

    # Estados da calibração
    state_map = {
        "0_NTU":    "🟡 Insira o frasco de 0 NTU",
        "100_NTU":  "🟡 Troque para o frasco de 100 NTU",
        "200_NTU":  "🟡 Troque para o frasco de 200 NTU",
        "300_NTU":  "🟡 Troque para o frasco de 300 NTU",
        "400_NTU":  "🟡 Troque para o frasco de 400 NTU",
        "500_NTU":  "🟡 Troque para o frasco de 500 NTU (último ponto)",
        "LENDO":    "⏳ ESP32 está capturando amostras...",
        "PROCESSANDO": "⚙️  Calculando regressão polinomial...",
        "CALIB_OK": "✅ Calibração concluída com sucesso!",
        "CALIB_CANCELADA": "🚫 Calibração cancelada pelo usuário",
    }
    if raw in state_map:
        log(f"   {state_map[raw]}", "STATE")
        return

    # Erros
    if raw.startswith("ERRO_"):
        error_map = {
            "ERRO_CONFIRM_FORA_DE_CONTEXTO": "CONFIRM enviado fora de ordem / sem calibração ativa",
            "ERRO_EM_CALIBRACAO":            "GET_TURBIDEZ enviado durante calibração ativa",
        }
        desc = error_map.get(raw.split(":")[0], "Erro desconhecido")
        if ":" in raw:
            desc += f" → detalhe: {raw.split(':', 1)[1]}"
        log(f"   ❌ ERRO: {desc}", "ERROR")
        return

    log(f"   ℹ Mensagem não mapeada: {raw!r}", "WARN")


# ══════════════════════════════════════════════
#  Menu interativo
# ══════════════════════════════════════════════

COMMANDS = {
    "1": ("START_CAL",    "Iniciar / Cancelar calibração"),
    "2": ("CONFIRM",      "Confirmar ponto atual (avançar)"),
    "3": ("GET_TURBIDEZ", "Solicitar leitura instantânea"),
    "q": (None,           "Sair"),
}

def print_menu():
    print("\n" + "─" * 45)
    print("  NEPTUS BLE TESTER — Comandos disponíveis")
    print("─" * 45)
    for key, (cmd, desc) in COMMANDS.items():
        label = cmd if cmd else "─"
        print(f"  [{key}]  {label:<18} {desc}")
    print("─" * 45)
    print("  Ou digite qualquer comando manualmente")
    print("─" * 45)


# ══════════════════════════════════════════════
#  Scan e Conexão
# ══════════════════════════════════════════════

async def scan_and_pick() -> str | None:
    """Escaneia dispositivos BLE e retorna o endereço escolhido."""
    log(f"Escaneando BLE por {SCAN_TIMEOUT_SEC}s (filtro: '{DEVICE_NAME_FILTER}')...")
    devices = await BleakScanner.discover(timeout=SCAN_TIMEOUT_SEC)

    matches = [d for d in devices if DEVICE_NAME_FILTER.lower() in (d.name or "").lower()]

    if not matches:
        log("Nenhum dispositivo encontrado. Listando todos:", "WARN")
        for i, d in enumerate(devices):
            print(f"  [{i}] {d.address}  {d.name or '(sem nome)'}")
        if not devices:
            log("Nenhum dispositivo BLE detectado.", "ERROR")
            return None
        choice = input("Escolha o número do dispositivo (ou Enter para cancelar): ").strip()
        if not choice.isdigit() or int(choice) >= len(devices):
            return None
        return devices[int(choice)].address

    if len(matches) == 1:
        log(f"Dispositivo encontrado: {matches[0].name} [{matches[0].address}]")
        return matches[0].address

    print("Múltiplos dispositivos encontrados:")
    for i, d in enumerate(matches):
        print(f"  [{i}] {d.address}  {d.name}")
    choice = input("Escolha o número: ").strip()
    if choice.isdigit() and int(choice) < len(matches):
        return matches[int(choice)].address
    return None


# ══════════════════════════════════════════════
#  Loop principal
# ══════════════════════════════════════════════

async def run(address: str):
    log(f"Conectando em {address}...")

    def notification_handler(_sender, data: bytearray):
        try:
            msg = data.decode("utf-8").strip()
        except UnicodeDecodeError:
            msg = data.hex()
        log_rx(msg)

    async with BleakClient(address) as client:
        if not client.is_connected:
            log("Falha na conexão.", "ERROR")
            return

        log(f"Conectado! MTU={client.mtu_size}")

        # Inscreve nas notificações TX (ESP32 → Python)
        await client.start_notify(NUS_TX_CHAR_UUID, notification_handler)
        log("Notificações TX ativas. Aguardando mensagens do ESP32...")

        print_menu()

        loop = asyncio.get_event_loop()

        while True:
            # Leitura de input sem bloquear o loop assíncrono
            try:
                user_input = await loop.run_in_executor(None, input, "\n> Comando: ")
            except (EOFError, KeyboardInterrupt):
                break

            user_input = user_input.strip()
            if not user_input:
                print_menu()
                continue

            if user_input.lower() == "q":
                log("Encerrando...")
                break

            # Resolve atalho numérico ou aceita comando literal
            if user_input in COMMANDS:
                cmd, _ = COMMANDS[user_input]
                if cmd is None:
                    break
            else:
                cmd = user_input.upper()

            log(f"→ Enviando: {cmd!r}", "TX")
            try:
                await client.write_gatt_char(
                    NUS_RX_CHAR_UUID,
                    cmd.encode("utf-8"),
                    response=False,   # Write Without Response (mais comum no NUS)
                )
            except Exception as e:
                log(f"Erro ao enviar: {e}", "ERROR")

            # Pequena pausa para deixar notificações chegarem antes do próximo prompt
            await asyncio.sleep(0.3)

        await client.stop_notify(NUS_TX_CHAR_UUID)
        log("Desconectado.")


# ══════════════════════════════════════════════
#  Fluxo de calibração automática (modo assistido)
# ══════════════════════════════════════════════

async def auto_calibration_flow(client: BleakClient):
    """
    Modo assistido: guia o desenvolvedor pelo fluxo completo de calibração
    passo a passo, aguardando o estado correto do ESP32 antes de avançar.
    Útil para validar o protocolo sem um app real.
    """
    log("=== MODO ASSISTIDO: Fluxo de Calibração ===", "INFO")

    received_states: list[str] = []
    calibration_done = asyncio.Event()
    expected_steps   = ["0_NTU", "100_NTU", "200_NTU", "300_NTU", "400_NTU", "500_NTU"]
    current_step     = {"idx": 0}

    def handler(_sender, data: bytearray):
        msg = data.decode("utf-8").strip()
        log_rx(msg)
        received_states.append(msg)
        if msg in ("CALIB_OK", "CALIB_CANCELADA", "ERRO_EM_CALIBRACAO"):
            calibration_done.set()

    await client.start_notify(NUS_TX_CHAR_UUID, handler)

    async def send(cmd: str):
        log(f"→ Enviando: {cmd!r}", "TX")
        await client.write_gatt_char(NUS_RX_CHAR_UUID, cmd.encode(), response=False)
        await asyncio.sleep(0.5)

    # Inicia calibração
    await send("START_CAL")

    for step in expected_steps:
        # Aguarda o ESP32 solicitar este ponto (timeout de 30s)
        waited = 0
        while step not in received_states and waited < 30:
            await asyncio.sleep(0.5)
            waited += 0.5

        if step not in received_states:
            log(f"Timeout esperando {step}!", "ERROR")
            break

        input(f"\n  ▶ Insira o frasco {step} e pressione ENTER para confirmar...")
        await send("CONFIRM")

        # Aguarda LENDO
        await asyncio.sleep(2)

    # Aguarda resultado final
    log("Aguardando CALIB_OK ou erro...")
    try:
        await asyncio.wait_for(calibration_done.wait(), timeout=60)
    except asyncio.TimeoutError:
        log("Timeout aguardando resultado da calibração.", "ERROR")

    await client.stop_notify(NUS_TX_CHAR_UUID)
    log("Fluxo assistido encerrado.")


# ══════════════════════════════════════════════
#  Entry-point
# ══════════════════════════════════════════════

async def main():
    print("=" * 50)
    print("  NEPTUS BLE Tester")
    print("  Comunicação ESP32 ↔ Python via BLE/NUS")
    print("=" * 50)

    address = await scan_and_pick()
    if not address:
        log("Nenhum dispositivo selecionado. Encerrando.", "ERROR")
        sys.exit(1)

    mode = input("\nModo de operação:\n  [1] Interativo (menu)\n  [2] Assistido (calibração automática)\n> ").strip()

    if mode == "2":
        async with BleakClient(address) as client:
            if client.is_connected:
                await auto_calibration_flow(client)
    else:
        await run(address)


if __name__ == "__main__":
    asyncio.run(main())